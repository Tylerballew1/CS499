import java.util.Date;

/******************************************************************
 * Name: Tyler Ballew
 * University: Southern New Hampshire University
 * Course: CS320
 * Date: 6/5/2026
 * Updated: 6/8/2026
 * 
 * Appointment.java
 * 
 * Description: This class builds the appointment object.
 * It also checks rules before saving anything in the appointment.
 * 
 ******************************************************************/

public class Appointment {

    private final String appointmentId;
    private Date appointmentDate;
    private String description;

    // Main constructor for creating an appointment
    public Appointment(String appointmentId, Date appointmentDate, String description) {

        // ID is required and must be 10 characters or less
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }

        // Date is required and cannot be in the past
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }

        // Description is required and must be 50 characters or less
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    // No setter for ID because the ID cannot be updated
    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    // Allows the date to be updated if it is still valid
    public void setAppointmentDate(Date appointmentDate) {

        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }

        this.appointmentDate = appointmentDate;
    }

    public String getDescription() {
        return description;
    }

    // Allows the description to be updated if it is valid
    public void setDescription(String description) {

        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.description = description;
    }
}