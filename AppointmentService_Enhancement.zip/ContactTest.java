/****************************************************
 *                                                  *
 *  Name: Tyler_Ballew                              *
 *  Southern New Hampshire University               *
 *  Course: CS 320                                  *
 *  Date: 05/22/2026                                *
 *  Updated: 6/8/2026                               *
 *                                                  *
 *  Description: JUnit tests for the contact object *
 *  and contact service requirements.               *
 *                                                  *
 ****************************************************/

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testContactCreatedSuccessfully() {
        // Test that a valid contact object can be created.
        Contact contact = new Contact("1234567890", "Tyler", "Ballew", "1111111111", "100 Street");

        assertEquals("1234567890", contact.getContactId());
        assertEquals("Tyler", contact.getFirstName());
        assertEquals("Ballew", contact.getLastName());
        assertEquals("1111111111", contact.getPhone());
        assertEquals("100 Street", contact.getAddress());
    }

    @Test
    public void testContactIdCannotBeNull() {
        // Contact ID is required.
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Tyler", "Ballew", "1111111111", "100 Street");
        });
    }

    @Test
    public void testContactIdCannotBeLongerThanTenCharacters() {
        // Contact ID cannot be longer than 10 characters.
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Tyler", "Ballew", "1111111111", "100 Street");
        });
    }

    @Test
    public void testFirstNameCannotBeNull() {
        // First name is required.
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Ballew", "1111111111", "100 Street");
        });
    }

    @Test
    public void testFirstNameCannotBeLongerThanTenCharacters() {
        // First name cannot be longer than 10 characters.
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Christopher", "Ballew", "1111111111", "100 Street");
        });
    }

    @Test
    public void testLastNameCannotBeNull() {
        // Last name is required.
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Tyler", null, "1111111111", "100 Street");
        });
    }

    @Test
    public void testLastNameCannotBeLongerThanTenCharacters() {
        // Last name cannot be longer than 10 characters.
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Tyler", "Longlastname", "1111111111", "100 Street");
        });
    }

    @Test
    public void testPhoneCannotBeNull() {
        // Phone number is required.
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Tyler", "Ballew", null, "100 Street");
        });
    }

    @Test
    public void testPhoneMustBeExactlyTenDigits() {
        // Phone number must not be shorter or longer than 10 digits.
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Tyler", "Ballew", "111111111", "100 Street");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Tyler", "Ballew", "11111111111", "100 Street");
        });
    }

    @Test
    public void testPhoneMustOnlyContainDigits() {
        // Phone number should only contain numeric digits.
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Tyler", "Ballew", "11111abcde", "100 Street");
        });
    }

    @Test
    public void testAddressCannotBeNull() {
        // Address is required.
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Tyler", "Ballew", "1111111111", null);
        });
    }

    @Test
    public void testAddressCannotBeLongerThanThirtyCharacters() {
        // Address cannot be longer than 30 characters.
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Tyler", "Ballew", "1111111111", "1234567890123456789012345678901");
        });
    }
}