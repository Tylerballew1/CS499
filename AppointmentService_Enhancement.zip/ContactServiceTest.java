/****************************************************
 *                                                  *
 *  Name: Tyler_Ballew                              *
 *  Southern New Hampshire University               *
 *  Course: CS 320                                  *
 *  Date: 05/22/2026                                *
 *  Updated: 6/8/2026                               *
 *                                                  *
 ****************************************************/

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    public void testAddContactSuccessfully() {
        // Test that a valid contact can be added to the service.
        ContactService service = new ContactService();
        Contact contact = new Contact("1234567890", "Tyler", "Ballew", "1111111111", "100 Street");

        assertTrue(service.addContact(contact));
        assertEquals(contact, service.getContact("1234567890"));
    }

    @Test
    public void testCannotAddDuplicateContactId() {
        // Test that duplicate contact IDs are not allowed.
        ContactService service = new ContactService();

        Contact contactOne = new Contact("1234567890", "Tyler", "Ballew", "1111111111", "100 Street");
        Contact contactTwo = new Contact("1234567890", "Olivia", "Ballew", "2222222222", "200 Street");

        assertTrue(service.addContact(contactOne));
        assertFalse(service.addContact(contactTwo));
    }

    @Test
    public void testCannotAddNullContact() {
        // Test that a null contact cannot be added.
        ContactService service = new ContactService();

        assertFalse(service.addContact(null));
    }

    @Test
    public void testDeleteContactSuccessfully() {
        // Test that an existing contact can be deleted by ID.
        ContactService service = new ContactService();
        Contact contact = new Contact("1234567890", "Tyler", "Ballew", "1111111111", "100 Street");

        service.addContact(contact);

        assertTrue(service.deleteContact("1234567890"));
        assertNull(service.getContact("1234567890"));
    }

    @Test
    public void testDeleteContactThatDoesNotExist() {
        // Test that deleting a missing contact returns false.
        ContactService service = new ContactService();

        assertFalse(service.deleteContact("99999"));
    }

    @Test
    public void testUpdateFirstNameSuccessfully() {
        // Test that the first name can be updated.
        ContactService service = new ContactService();
        Contact contact = new Contact("1234567890", "Tyler", "Ballew", "1111111111", "100 Street");

        service.addContact(contact);

        assertTrue(service.updateFirstName("1234567890", "John"));
        assertEquals("John", service.getContact("1234567890").getFirstName());
    }

    @Test
    public void testUpdateLastNameSuccessfully() {
        // Test that the last name can be updated.
        ContactService service = new ContactService();
        Contact contact = new Contact("1234567890", "Tyler", "Ballew", "1111111111", "100 Street");

        service.addContact(contact);

        assertTrue(service.updateLastName("1234567890", "Smith"));
        assertEquals("Smith", service.getContact("1234567890").getLastName());
    }

    @Test
    public void testUpdatePhoneSuccessfully() {
        // Test that the phone number can be updated.
        ContactService service = new ContactService();
        Contact contact = new Contact("1234567890", "Tyler", "Ballew", "1111111111", "100 Street");

        service.addContact(contact);

        assertTrue(service.updatePhone("1234567890", "2222222222"));
        assertEquals("2222222222", service.getContact("1234567890").getPhone());
    }

    @Test
    public void testUpdateAddressSuccessfully() {
        // Test that the address can be updated.
        ContactService service = new ContactService();
        Contact contact = new Contact("1234567890", "Tyler", "Ballew", "1111111111", "100 Street");

        service.addContact(contact);

        assertTrue(service.updateAddress("1234567890", "200 Street"));
        assertEquals("200 Street", service.getContact("1234567890").getAddress());
    }

    @Test
    public void testUpdateContactThatDoesNotExist() {
        // Test that updates fail when the contact ID does not exist.
        ContactService service = new ContactService();

        assertFalse(service.updateFirstName("99999", "John"));
        assertFalse(service.updateLastName("99999", "Smith"));
        assertFalse(service.updatePhone("99999", "2222222222"));
        assertFalse(service.updateAddress("99999", "200 Street"));
    }

    @Test
    public void testUpdateWithInvalidValuesThrowsException() {
        // Test that invalid updates still follow the contact field rules.
        ContactService service = new ContactService();
        Contact contact = new Contact("1234567890", "Tyler", "Ballew", "1111111111", "100 Street");

        service.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("1234567890", "Christopher");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateLastName("1234567890", "Longlastname");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            service.updatePhone("1234567890", "123");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateAddress("1234567890", "1234567890123456789012345678901");
        });
    }
}
