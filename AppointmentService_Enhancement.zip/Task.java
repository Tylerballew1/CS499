/****************************************************
 *                                                  *
 *  Name: Tyler_Ballew                              *
 *  Southern New Hampshire University               *
 *  Course: CS 320                                  *
 *  Date: 05/29/2026                                *
 *  Updated: 6/8/2026                               *
 *                                                  * 
 *  Description: Module 4                           *
 *                                                  *
 ****************************************************/

public class Task {

    private final String taskId;
    private String name;
    private String description;

    // Constructor creates a task and checks all required fields.
    public Task(String taskId, String name, String description) {

        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID");
        }

        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }

        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // Task ID can be viewed but cannot be changed.
    public String getTaskId() {
        return taskId;
    }

    // Name can be viewed and updated through the service.
    public String getName() {
        return name;
    }

    // Description can be viewed and updated through the service.
    public String getDescription() {
        return description;
    }

    // Updates the task name after checking the requirement.
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }

        this.name = name;
    }

    // Updates the task description after checking the requirement.
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.description = description;
    }
}