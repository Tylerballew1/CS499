# Update for CS499
The application was developed using Java and can be opened in Visual Studio Code with Java development support. Apache Maven and JUnit 5 are used to manage the testing environment and verify that the application functions correctly.

-Tyler Ballew

# CS320
Computer Science 320
Tyler Ballew

## How can I ensure that my code, program, or software is functional and secure? ##

I can ensure that my software is functional by testing it against every requirement. In these projects, I used JUnit tests to check valid information and reject invalid information. I tested character limits, null values, duplicate IDs, and required fields. I also tested service functions such as adding, updating, and deleting records. To improve security, I use input validation so incorrect or harmful data is not accepted by the program. Regular testing and reviewing the code can help uncover problems before the software is released.

## How do I interpret user needs and incorporate them into a program? ##

I interpret user needs by reviewing the requirements and identifying exactly what the program must do. I treat the requirements like a checklist during both development and testing. For example, the contact service required unique contact IDs and limits for each contact field. I used those requirements to create the contact class, service methods, and unit tests. Testing each requirement helped confirm that the finished program matched what the customer requested. Clear requirements also reduce confusion and prevent unnecessary features from being added.

## How do I approach designing software? ##

I approach software design by first breaking the project into smaller and more manageable parts. I determine what objects, fields, methods, and services are needed before writing the complete program. For the contact service, I separated the contact object from the service that manages the contacts. This made the program easier to understand, test, and update. I also considered possible errors, such as duplicate IDs or invalid field lengths, while designing the software. My goal is to create code that is simple, organized, and directly connected to the project requirements.
