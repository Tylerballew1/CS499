import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Test;

/******************************************************************
 * Name: Tyler Ballew
 * University: Southern New Hampshire University
 * Course: CS320
 * Date: 6/5/2026
 * Updated: 6/8/2026
 * 
 * AppointmentTest.java
 * 
 * Description: This class checks appointment object rules. Data
 * will either work if it is positive or fail if data is negative.
 * 
 ******************************************************************/

class AppointmentTest {

    // Makes a date for tomorrow
    private Date getFutureDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, 1);
        return calendar.getTime();
    }

    // Makes a date for yesterday
    private Date getPastDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1);
        return calendar.getTime();
    }

    @Test
    void testAppointmentCreatedSuccessfully() {
        Date futureDate = getFutureDate();

        Appointment appointment = new Appointment("1234567890", futureDate, "Doctor appointment");

        assertEquals("1234567890", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Doctor appointment", appointment.getDescription());
    }

    @Test
    void testAppointmentIdTooLong() {
        Date futureDate = getFutureDate();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Doctor appointment");
        });
    }

    @Test
    void testAppointmentIdNull() {
        Date futureDate = getFutureDate();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Doctor appointment");
        });
    }

    @Test
    void testAppointmentDateNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", null, "Doctor appointment");
        });
    }

    @Test
    void testAppointmentDateInPast() {
        Date pastDate = getPastDate();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", pastDate, "Doctor appointment");
        });
    }

    @Test
    void testDescriptionTooLong() {
        Date futureDate = getFutureDate();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", futureDate,
                    "This description is too long because it has more than fifty characters.");
        });
    }

    @Test
    void testDescriptionNull() {
        Date futureDate = getFutureDate();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", futureDate, null);
        });
    }

    @Test
    void testSetAppointmentDate() {
        Appointment appointment = new Appointment("1234567890", getFutureDate(), "Doctor appointment");

        Date newFutureDate = getFutureDate();
        appointment.setAppointmentDate(newFutureDate);

        assertEquals(newFutureDate, appointment.getAppointmentDate());
    }

    @Test
    void testSetAppointmentDateInPast() {
        Appointment appointment = new Appointment("1234567890", getFutureDate(), "Doctor appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(getPastDate());
        });
    }

    @Test
    void testSetDescription() {
        Appointment appointment = new Appointment("1234567890", getFutureDate(), "Doctor appointment");

        appointment.setDescription("Dentist appointment");

        assertEquals("Dentist appointment", appointment.getDescription());
    }

    @Test
    void testSetDescriptionTooLong() {
        Appointment appointment = new Appointment("1234567890", getFutureDate(), "Doctor appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription("This description is too long because it has more than fifty characters.");
        });
    }
}
