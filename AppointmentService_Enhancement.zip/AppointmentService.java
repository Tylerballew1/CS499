import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Date;

/******************************************************************
 * Name: Tyler Ballew
 * University: Southern New Hampshire University
 * Course: CS320         Updated Course: CS499
 * Date: 6/5/2026        Last Updated:11/16/2026
 * Updated: 6/8/2026     Reason: Enhancement Artifact 2
 *                       Algorithms and Data Structure           
 * AppointmentService.java
 * 
 * Description: Class is built to hold appointments in its memory.
 * It can add and delete appointments as needed per user.
 * 
 ******************************************************************/

public class AppointmentService {

    private final Map<String, Appointment> appointments = new HashMap<>();

    // Adds an appointment only if the appointment is real and the ID is unique
    public void addAppointment(Appointment appointment) {

        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null");
        }

        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID already exists");
        }

        appointments.put(appointment.getAppointmentId(), appointment);
    }

    // Deletes an appointment by ID
    public void deleteAppointment(String appointmentId) {

        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID does not exist");
        }

        appointments.remove(appointmentId);
    }

    // Used by the tests to check if the appointment is there
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }

    // Enhancement 1: Sort appointments by date
    // Uses an ArrayList and Comparator to put appointments in date order
    public List<Appointment> getAppointmentsSortedByDate() {

        List<Appointment> sortedAppointments =
                new ArrayList<>(appointments.values());

        sortedAppointments.sort(
                Comparator.comparing(Appointment::getAppointmentDate)
        );

        return sortedAppointments;
    }

    // Enhancement 2: Search appointments within a date range
    // Finds appointments between the start and end dates
    public List<Appointment> getAppointmentsByDateRange(Date startDate, Date endDate) {

        if (startDate == null || endDate == null || startDate.after(endDate)) {
            throw new IllegalArgumentException("Invalid date range");
        }

        List<Appointment> results = new ArrayList<>();

        for (Appointment appointment : appointments.values()) {

            Date appointmentDate = appointment.getAppointmentDate();

            if (!appointmentDate.before(startDate) &&
                    !appointmentDate.after(endDate)) {
                results.add(appointment);
            }
        }

        results.sort(Comparator.comparing(Appointment::getAppointmentDate));

        return results;
    }

    // Enhancement 3: Find upcoming appointments
    // Returns appointments scheduled after the date provided
    public List<Appointment> getUpcomingAppointments(Date currentDate) {

        if (currentDate == null) {
            throw new IllegalArgumentException("Date cannot be null");
        }

        List<Appointment> upcomingAppointments = new ArrayList<>();

        for (Appointment appointment : appointments.values()) {

            if (appointment.getAppointmentDate().after(currentDate)) {
                upcomingAppointments.add(appointment);
            }
        }

        upcomingAppointments.sort(
                Comparator.comparing(Appointment::getAppointmentDate)
        );

        return upcomingAppointments;
    }

    // Enhancement 4: Reschedule an existing appointment
    // Finds an appointment by ID and updates it with a valid date
    public void rescheduleAppointment(String appointmentId, Date newDate) {

        Appointment appointment = appointments.get(appointmentId);

        if (appointment == null) {
            throw new IllegalArgumentException("Appointment ID does not exist");
        }

        appointment.setAppointmentDate(newDate);
    }

    // Enhancement 5: Check for appointment conflicts
    // Checks whether another appointment already has the same date and time
    public boolean hasAppointmentConflict(Date appointmentDate) {

        if (appointmentDate == null) {
            throw new IllegalArgumentException("Date cannot be null");
        }

        for (Appointment appointment : appointments.values()) {

            if (appointment.getAppointmentDate().equals(appointmentDate)) {
                return true;
            }
        }

        return false;
    }
}