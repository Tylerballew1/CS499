/****************************************************
 *                                                  *
 *  Name: Tyler_Ballew                              *
 *  Southern New Hampshire University               *
 *  Course: CS 320                                  *
 *  Date: 05/22/2026                                *
 *  Updated: 6/8/2026                               *
 ****************************************************/

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    // HashMap stores contacts in memory using the contact ID as the key.
    private final Map<String, Contact> contacts = new HashMap<>();

    public boolean addContact(Contact contact) {
        // A contact cannot be added if it is null or the ID already exists.
        if (contact == null || contacts.containsKey(contact.getContactId())) {
            return false;
        }

        contacts.put(contact.getContactId(), contact);
        return true;
    }

    public boolean deleteContact(String contactId) {
        // Return false if there is no contact with the given ID.
        if (!contacts.containsKey(contactId)) {
            return false;
        }

        contacts.remove(contactId);
        return true;
    }

    public boolean updateFirstName(String contactId, String firstName) {
        Contact contact = contacts.get(contactId);

        // Return false if the contact cannot be found.
        if (contact == null) {
            return false;
        }

        contact.setFirstName(firstName);
        return true;
    }

    public boolean updateLastName(String contactId, String lastName) {
        Contact contact = contacts.get(contactId);

        // Return false if the contact cannot be found.
        if (contact == null) {
            return false;
        }

        contact.setLastName(lastName);
        return true;
    }

    public boolean updatePhone(String contactId, String phone) {
        Contact contact = contacts.get(contactId);

        // Return false if the contact cannot be found.
        if (contact == null) {
            return false;
        }

        contact.setPhone(phone);
        return true;
    }

    public boolean updateAddress(String contactId, String address) {
        Contact contact = contacts.get(contactId);

        // Return false if the contact cannot be found.
        if (contact == null) {
            return false;
        }

        contact.setAddress(address);
        return true;
    }

    public Contact getContact(String contactId) {
        // Used by tests to verify that contacts were added, deleted, or updated.
        return contacts.get(contactId);
    }
}
