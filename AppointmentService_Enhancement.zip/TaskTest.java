/****************************************************
 *                                                  *
 *  Name: Tyler_Ballew                              *
 *  Southern New Hampshire University               *
 *  Course: CS 320                                  *
 *  Date: 05/29/2026      Updated: 6/8/2026         *
 *  Description: Module 4                           *
 *                                                  *
 ****************************************************/

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testTaskCreation() {
        // Checks that a task can be created with valid information.
        Task task = new Task("1234567890", "Task Name", "This is a task description.");

        assertEquals("1234567890", task.getTaskId());
        assertEquals("Task Name", task.getName());
        assertEquals("This is a task description.", task.getDescription());
    }

    @Test
    public void testTaskIdTooLong() {
        // Checks that the task ID cannot be more than 10 characters.
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Task Name", "This is a task description.");
        });
    }

    @Test
    public void testTaskIdNull() {
        // Checks that the task ID cannot be null.
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Task Name", "This is a task description.");
        });
    }

    @Test
    public void testNameTooLong() {
        // Checks that the name cannot be more than 20 characters.
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "This name is way too long", "This is a task description.");
        });
    }

    @Test
    public void testNameNull() {
        // Checks that the name cannot be null.
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", null, "This is a task description.");
        });
    }

    @Test
    public void testDescriptionTooLong() {
        // Checks that the description cannot be more than 50 characters.
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "Task Name",
                    "This description is way too long because it has more than fifty characters.");
        });
    }

    @Test
    public void testDescriptionNull() {
        // Checks that the description cannot be null.
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "Task Name", null);
        });
    }

    @Test
    public void testSetName() {
        // Checks that the task name can be updated.
        Task task = new Task("1234567890", "Task Name", "This is a task description.");

        task.setName("Updated Name");

        assertEquals("Updated Name", task.getName());
    }

    @Test
    public void testSetDescription() {
        // Checks that the task description can be updated.
        Task task = new Task("1234567890", "Task Name", "This is a task description.");

        task.setDescription("Updated description.");

        assertEquals("Updated description.", task.getDescription());
    }
}
