/****************************************************
 *                                                  *
 *  Name: Tyler_Ballew                              *
 *  Southern New Hampshire University               *
 *  Course: CS 320                                  *
 *  Date: 05/29/2026   Updated: 6/8/2026            *
 *  Description: Module 4                           *
 *                                                  *
 ****************************************************/

import java.util.HashMap;
import java.util.Map;

public class TaskService {

    private final Map<String, Task> tasks = new HashMap<>();

    // Adds a task only if the task ID is unique.
    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null");
        }

        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists");
        }

        tasks.put(task.getTaskId(), task);
    }

    // Deletes a task by task ID.
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found");
        }

        tasks.remove(taskId);
    }

    // Updates the task name by task ID.
    public void updateTaskName(String taskId, String name) {
        Task task = tasks.get(taskId);

        if (task == null) {
            throw new IllegalArgumentException("Task ID not found");
        }

        task.setName(name);
    }

    // Updates the task description by task ID.
    public void updateTaskDescription(String taskId, String description) {
        Task task = tasks.get(taskId);

        if (task == null) {
            throw new IllegalArgumentException("Task ID not found");
        }

        task.setDescription(description);
    }

    // Helps with testing to confirm a task exists.
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}