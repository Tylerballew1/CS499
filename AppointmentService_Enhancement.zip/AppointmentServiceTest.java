import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;

/******************************************************************
 * Name: Tyler Ballew
 * University: Southern New Hampshire University
 * Course: CS320         Updated Course: CS499
 * Date: 6/5/2026        Last Updated:11/16/2026
 * Updated: 6/8/2026     Reason: Enhancement Artifact 2
 *                       Algorithms and Data Structure    
 * AppointmentServiceTest.java
 * 
 * Description: These test check the appointment rules. Allowing the
 * service to add or delete appointments correctly.
 * 
 ******************************************************************/
class AppointmentServiceTest {

    // Makes a date for tomorrow
    private Date getFutureDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, 1);
        return calendar.getTime();
    }

    @Test
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("1234567890", getFutureDate(), "Doctor appointment");

        service.addAppointment(appointment);

        assertEquals(appointment, service.getAppointment("1234567890"));
    }

    @Test
    void testAddDuplicateAppointmentId() {
        AppointmentService service = new AppointmentService();

        Appointment appointmentOne = new Appointment("1234567890", getFutureDate(), "Doctor appointment");
        Appointment appointmentTwo = new Appointment("1234567890", getFutureDate(), "Dentist appointment");

        service.addAppointment(appointmentOne);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointmentTwo);
        });
    }

    @Test
    void testAddNullAppointment() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(null);
        });
    }

    @Test
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("1234567890", getFutureDate(), "Doctor appointment");

        service.addAppointment(appointment);
        service.deleteAppointment("1234567890");

        assertNull(service.getAppointment("1234567890"));
    }

    @Test
    void testDeleteAppointmentNotFound() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("9999999999");
        });
    }

    // Enhancement 1: Test appointments sorted by date
    // Checks that appointments are returned from earliest to latest
    @Test
    void testAppointmentsSortedByDate() {
        AppointmentService service = new AppointmentService();

        Calendar calendar = Calendar.getInstance();

        calendar.add(Calendar.DATE, 5);
        Date dateFive = calendar.getTime();

        calendar.add(Calendar.DATE, -3);
        Date dateTwo = calendar.getTime();

        calendar.add(Calendar.DATE, 1);
        Date dateThree = calendar.getTime();

        service.addAppointment(new Appointment("A001", dateFive, "Appointment five"));
        service.addAppointment(new Appointment("A002", dateTwo, "Appointment two"));
        service.addAppointment(new Appointment("A003", dateThree, "Appointment three"));

        List<Appointment> results = service.getAppointmentsSortedByDate();

        assertEquals(3, results.size());
        assertEquals("A002", results.get(0).getAppointmentId());
        assertEquals("A003", results.get(1).getAppointmentId());
        assertEquals("A001", results.get(2).getAppointmentId());
    }

    // Enhancement 2: Test searching between two dates
    // Checks that only appointments within the date range are returned
    @Test
    void testAppointmentsByDateRange() {
        AppointmentService service = new AppointmentService();

        Calendar calendar = Calendar.getInstance();

        calendar.add(Calendar.DATE, 1);
        Date dateOne = calendar.getTime();

        calendar.add(Calendar.DATE, 2);
        Date dateThree = calendar.getTime();

        calendar.add(Calendar.DATE, 3);
        Date dateSix = calendar.getTime();

        service.addAppointment(new Appointment("A001", dateOne, "First appointment"));
        service.addAppointment(new Appointment("A002", dateThree, "Second appointment"));
        service.addAppointment(new Appointment("A003", dateSix, "Third appointment"));

        List<Appointment> results =
                service.getAppointmentsByDateRange(dateOne, dateThree);

        assertEquals(2, results.size());
        assertEquals("A001", results.get(0).getAppointmentId());
        assertEquals("A002", results.get(1).getAppointmentId());
    }

    // Enhancement 2: Test invalid date range
    // Checks that an end date before the start date is rejected
    @Test
    void testInvalidDateRange() {
        AppointmentService service = new AppointmentService();

        Calendar calendar = Calendar.getInstance();

        calendar.add(Calendar.DATE, 5);
        Date laterDate = calendar.getTime();

        calendar.add(Calendar.DATE, -3);
        Date earlierDate = calendar.getTime();

        assertThrows(IllegalArgumentException.class, () -> {
            service.getAppointmentsByDateRange(laterDate, earlierDate);
        });
    }

    // Enhancement 3: Test upcoming appointments
    // Checks that only appointments after the provided date are returned
    @Test
    void testUpcomingAppointments() {
        AppointmentService service = new AppointmentService();

        Calendar calendar = Calendar.getInstance();

        calendar.add(Calendar.DATE, 1);
        Date dateOne = calendar.getTime();

        calendar.add(Calendar.DATE, 4);
        Date dateFive = calendar.getTime();

        service.addAppointment(new Appointment("A001", dateOne, "Earlier appointment"));
        service.addAppointment(new Appointment("A002", dateFive, "Later appointment"));

        List<Appointment> results = service.getUpcomingAppointments(dateOne);

        assertEquals(1, results.size());
        assertEquals("A002", results.get(0).getAppointmentId());
    }

    // Enhancement 4: Test rescheduling an appointment
    // Checks that an appointment date can be updated
    @Test
    void testRescheduleAppointment() {
        AppointmentService service = new AppointmentService();

        Date originalDate = getFutureDate();

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, 7);
        Date newDate = calendar.getTime();

        Appointment appointment =
                new Appointment("A001", originalDate, "Doctor appointment");

        service.addAppointment(appointment);
        service.rescheduleAppointment("A001", newDate);

        assertEquals(newDate, service.getAppointment("A001").getAppointmentDate());
    }

    // Enhancement 4: Test rescheduling an appointment that does not exist
    // Checks that the service rejects an invalid appointment ID
    @Test
    void testRescheduleAppointmentNotFound() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.rescheduleAppointment("INVALID", getFutureDate());
        });
    }

    // Enhancement 5: Test appointment conflict detection
    // Checks whether another appointment already has the same date and time
    @Test
    void testAppointmentConflict() {
        AppointmentService service = new AppointmentService();

        Date appointmentDate = getFutureDate();

        service.addAppointment(
                new Appointment("A001", appointmentDate, "Doctor appointment")
        );

        assertTrue(service.hasAppointmentConflict(appointmentDate));
    }

    // Enhancement 5: Test when no appointment conflict exists
    // Checks that a different date does not create a conflict
    @Test
    void testNoAppointmentConflict() {
        AppointmentService service = new AppointmentService();

        Date appointmentDate = getFutureDate();

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, 5);
        Date differentDate = calendar.getTime();

        service.addAppointment(
                new Appointment("A001", appointmentDate, "Doctor appointment")
        );

        assertFalse(service.hasAppointmentConflict(differentDate));
    }
        // Enhancement 2: Test null dates in date range search
    // Checks that the service rejects missing start or end dates
    @Test
    void testNullDateRange() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.getAppointmentsByDateRange(null, getFutureDate());
        });

        assertThrows(IllegalArgumentException.class, () -> {
            service.getAppointmentsByDateRange(getFutureDate(), null);
        });
    }

    // Enhancement 3: Test upcoming appointments with no results
    // Checks that an empty list is returned when no appointments exist
    @Test
    void testUpcomingAppointmentsEmpty() {
        AppointmentService service = new AppointmentService();

        assertTrue(service.getUpcomingAppointments(new Date()).isEmpty());
    }

    // Enhancement 4: Test rescheduling to a past date
    // Checks that invalid appointment dates are rejected
    @Test
    void testReschedulePastDate() {
        AppointmentService service = new AppointmentService();

        Appointment appointment =
                new Appointment("A001", getFutureDate(), "Doctor appointment");

        service.addAppointment(appointment);

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1);
        Date pastDate = calendar.getTime();

        assertThrows(IllegalArgumentException.class, () -> {
            service.rescheduleAppointment("A001", pastDate);
        });
    }
}