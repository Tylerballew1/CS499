/****************************************************
 *                                                  *
 *  Name: Tyler_Ballew                              *
 *  Southern New Hampshire University               *
 *  Course: CS 320                                  *
 *  Date: 05/29/2026   Updated: 6/8/2026            *
 *  Description: Module 4                           *
 *                                                  *
 ****************************************************/

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    public void testAddTask() {
        // Checks that a task can be added to the service.
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "Task Name", "This is a task description.");

        service.addTask(task);

        assertEquals(task, service.getTask("1234567890"));
    }

    @Test
    public void testAddDuplicateTaskId() {
        // Checks that two tasks cannot have the same task ID.
        TaskService service = new TaskService();
        Task taskOne = new Task("1234567890", "Task Name", "This is a task description.");
        Task taskTwo = new Task("1234567890", "Other Task", "This is another task.");

        service.addTask(taskOne);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(taskTwo);
        });
    }

    @Test
    public void testAddNullTask() {
        // Checks that a null task cannot be added.
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(null);
        });
    }

    @Test
    public void testDeleteTask() {
        // Checks that a task can be deleted by task ID.
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "Task Name", "This is a task description.");

        service.addTask(task);
        service.deleteTask("1234567890");

        assertNull(service.getTask("1234567890"));
    }

    @Test
    public void testDeleteTaskNotFound() {
        // Checks that the service does not delete a task that does not exist.
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("1234567890");
        });
    }

    @Test
    public void testUpdateTaskName() {
        // Checks that a task name can be updated by task ID.
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "Task Name", "This is a task description.");

        service.addTask(task);
        service.updateTaskName("1234567890", "Updated Name");

        assertEquals("Updated Name", service.getTask("1234567890").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        // Checks that a task description can be updated by task ID.
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "Task Name", "This is a task description.");

        service.addTask(task);
        service.updateTaskDescription("1234567890", "Updated description.");

        assertEquals("Updated description.", service.getTask("1234567890").getDescription());
    }

    @Test
    public void testUpdateNameTaskNotFound() {
        // Checks that the name cannot be updated if the task ID is not found.
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("1234567890", "Updated Name");
        });
    }

    @Test
    public void testUpdateDescriptionTaskNotFound() {
        // Checks that the description cannot be updated if the task ID is not found.
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskDescription("1234567890", "Updated description.");
        });
    }

    @Test
    public void testUpdateNameTooLong() {
        // Checks that the updated name still follows the 20 character limit.
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "Task Name", "This is a task description.");

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("1234567890", "This name is way too long");
        });
    }

    @Test
    public void testUpdateDescriptionTooLong() {
        // Checks that the updated description still follows the 50 character limit.
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "Task Name", "This is a task description.");

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskDescription("1234567890",
                    "This description is way too long because it has more than fifty characters.");
        });
    }
}
