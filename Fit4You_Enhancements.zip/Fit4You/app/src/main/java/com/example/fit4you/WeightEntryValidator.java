// CS499 Capstone Enhancement
// Tyler Ballew @SNHU
package com.example.fit4you;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

// Enhancement 3.1: Keep weight and date validation
// in one reusable class.
public final class WeightEntryValidator {

    private static final DateTimeFormatter DATE_FORMAT =
            DateTimeFormatter.ofPattern("MM/dd/uuuu")
                    .withResolverStyle(ResolverStyle.STRICT);

    private WeightEntryValidator() {
        // Utility class; no instances required.
    }

    // Reject zero, negative, NaN, and infinite weight values.
    public static boolean isValidWeight(double weight) {
        return Double.isFinite(weight) && weight > 0;
    }

    // Reject missing, incorrectly formatted,
    // and impossible calendar dates.
    public static boolean isValidDate(String date) {
        if (date == null || date.isEmpty()) {
            return false;
        }

        try {
            LocalDate.parse(date, DATE_FORMAT);
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }

    // New weight entries and newly selected
    // edit dates must be today.
    public static boolean isToday(String date) {
        if (!isValidDate(date)) {
            return false;
        }

        return LocalDate.parse(
                date, DATE_FORMAT).equals(LocalDate.now());
    }
}