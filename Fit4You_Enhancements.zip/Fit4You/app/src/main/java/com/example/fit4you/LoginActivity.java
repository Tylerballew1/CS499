package com.example.fit4you;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        // Initialize the Fit4You database
        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        databaseHelper.getWritableDatabase();
        databaseHelper.close();

        // Connect the account registration fields and button
        EditText editUsername = findViewById(R.id.editUsername);
        EditText editPassword = findViewById(R.id.editPassword);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);
        Button buttonLogin = findViewById(R.id.buttonLogin);

        // Save a new user when Create Account is pressed
        buttonCreateAccount.setOnClickListener(view -> {

            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString();

            // Check that both fields have been completed
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Please enter a username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Register the new account in SQLite
            boolean success = databaseHelper.registerUser(username, password);

            if (success) {
                Toast.makeText(this,
                        "Account created successfully!",
                        Toast.LENGTH_LONG).show();

                editUsername.setText("");
                editPassword.setText("");

            } else {
                Toast.makeText(this,
                        "Unable to create account. Username may already exist.",
                        Toast.LENGTH_LONG).show();
            }
        });

        // Verify user credentials when Login is pressed.
        buttonLogin.setOnClickListener(view -> {

            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString();

            // Make sure the user entered both fields.
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Please enter a username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Check the entered credentials against SQLite.
            boolean validLogin = databaseHelper.loginUser(
                    username, password);

            if (validLogin) {

                Toast.makeText(this,
                        "Login successful!",
                        Toast.LENGTH_SHORT).show();

                // Open the weight tracking screen.
                Intent intent = new Intent(
                        LoginActivity.this, MainActivity.class);

                intent.putExtra("username", username);
                startActivity(intent);
                finish();

            } else {

                Toast.makeText(this,
                        "Incorrect username or password",
                        Toast.LENGTH_LONG).show();
            }
        });

        // Keeps the screen clear of system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.loginMain), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Finds the hamburger menu button
        ImageButton buttonLoginMenu = findViewById(R.id.buttonLoginMenu);

        // Opens the navigation menu
        buttonLoginMenu.setOnClickListener(view -> {

            PopupMenu popupMenu = new PopupMenu(LoginActivity.this, buttonLoginMenu);
            popupMenu.getMenuInflater().inflate(R.menu.navigation_menu, popupMenu.getMenu());

            popupMenu.setOnMenuItemClickListener(item -> {

                // Already on the login screen
                if (item.getItemId() == R.id.menuLogin) {
                    return true;
                }

                // Opens the weight tracker screen
                if (item.getItemId() == R.id.menuWeightTracker) {
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    return true;
                }

                // Opens the SMS notification screen
                if (item.getItemId() == R.id.menuSms) {
                    Intent intent = new Intent(LoginActivity.this, SmsActivity.class);
                    startActivity(intent);
                    return true;
                }

                return false;
            });

            popupMenu.show();
        });
    }
}