package com.example.fit4you;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.UUID;

public class GuestHelper {

    // Identifies the current user or creates a local guest profile.
    public static String resolveUsername(
            Context context, String username) {

        // Registered users continue using their own accounts.
        if (username != null && !username.trim().isEmpty()) {
            return username;
        }

        // Remember the guest profile on this device.
        SharedPreferences preferences = context.getSharedPreferences(
                "Fit4YouGuestProfile", Context.MODE_PRIVATE);

        String guestUsername = preferences.getString(
                "guest_username", null);

        if (guestUsername != null) {
            return guestUsername;
        }

        // Create a unique internal profile for guest storage.
        guestUsername = "fit4you_guest_" + UUID.randomUUID();

        String randomPassword = UUID.randomUUID().toString()
                + UUID.randomUUID();

        boolean created;

// Automatically close the database helper when finished.
        try (DatabaseHelper databaseHelper = new DatabaseHelper(context)) {
            created = databaseHelper.registerUser(
                    guestUsername, randomPassword);
        }

        if (created) {
            preferences.edit()
                    .putString("guest_username", guestUsername)
                    .apply();

            return guestUsername;
        }

        return null;
    }
}
