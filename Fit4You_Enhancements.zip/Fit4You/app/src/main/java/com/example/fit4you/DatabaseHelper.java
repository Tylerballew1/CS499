package com.example.fit4you;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import android.database.Cursor;
import java.security.MessageDigest;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Fit4You.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Stores user accounts.
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password_hash TEXT NOT NULL)");

        // Stores daily weight entries.
        db.execSQL("CREATE TABLE weights (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "weight REAL NOT NULL, " +
                "date TEXT NOT NULL, " +
                "FOREIGN KEY(user_id) REFERENCES users(id))");

        // Stores each user's goal weight.
        db.execSQL("CREATE TABLE goals (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER UNIQUE NOT NULL, " +
                "goal_weight REAL NOT NULL, " +
                "FOREIGN KEY(user_id) REFERENCES users(id))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {
        // Future database upgrades can go here.
    }

    // Creates a new user account in the database.
    public boolean registerUser(String username, String password) {

        if (username == null || username.trim().isEmpty()
                || password == null || password.isEmpty()) {
            return false;
        }

        try {
            // Securely hash the password before storing it.
            String passwordHash = hashPassword(password);

            ContentValues values = new ContentValues();
            values.put("username", username.trim());
            values.put("password_hash", passwordHash);

            SQLiteDatabase db = getWritableDatabase();

            long result = db.insertOrThrow(
                    "users", null, values);

            return result != -1;

        } catch (Exception e) {
            return false;
        }
    }

    // Uses a unique salt to protect each stored password.
    private String hashPassword(String password) throws Exception {

        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);

        PBEKeySpec spec = new PBEKeySpec(
                password.toCharArray(), salt, 120000, 256);

        try {
            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            byte[] hash = factory.generateSecret(spec).getEncoded();

            return Base64.getEncoder().encodeToString(salt)
                    + ":" + Base64.getEncoder().encodeToString(hash);

        } finally {
            spec.clearPassword();
        }
    }
    // Checks if the username and password match an existing account.
    public boolean loginUser(String username, String password) {

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT password_hash FROM users WHERE username = ?",
                new String[]{username.trim()})) {

            // Check whether the account exists.
            if (cursor.moveToFirst()) {
                String storedHash = cursor.getString(0);
                return verifyPassword(password, storedHash);
            }

        } catch (Exception e) {
            return false;
        }

        return false;
    }

    // Compares the entered password with the saved password hash.
    private boolean verifyPassword(String password, String storedHash)
            throws Exception {

        String[] parts = storedHash.split(":");

        if (parts.length != 2) {
            return false;
        }

        byte[] salt = Base64.getDecoder().decode(parts[0]);
        byte[] originalHash = Base64.getDecoder().decode(parts[1]);

        PBEKeySpec spec = new PBEKeySpec(
                password.toCharArray(), salt, 120000, 256);

        try {
            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            byte[] enteredHash = factory.generateSecret(spec).getEncoded();

            return MessageDigest.isEqual(originalHash, enteredHash);

        } finally {
            spec.clearPassword();
        }
    }
    // Saves a daily weight entry for a specific user.
    public boolean addWeight(String username, double weight, String date) {

        SQLiteDatabase db = getWritableDatabase();

        // Find the user's account ID.
        try (Cursor cursor = db.rawQuery(
                "SELECT id FROM users WHERE username = ?",
                new String[]{username})) {

            if (!cursor.moveToFirst()) {
                return false;
            }

            int userId = cursor.getInt(0);

            // Prepare the weight information.
            ContentValues values = new ContentValues();
            values.put("user_id", userId);
            values.put("weight", weight);
            values.put("date", date);

            // Insert the new weight into SQLite.
            long result = db.insert("weights", null, values);

            return result != -1;
        }
    }
    // Retrieves all saved weight entries for a specific user.
    public Cursor getUserWeights(String username) {

        SQLiteDatabase db = getReadableDatabase();

        return db.rawQuery(
                "SELECT weights.id, weights.date, weights.weight " +
                        "FROM weights " +
                        "INNER JOIN users ON weights.user_id = users.id " +
                        "WHERE users.username = ? " +
                        "ORDER BY weights.id DESC",
                new String[]{username}
        );
    }
    // Deletes a saved weight entry belonging to a specific user.
    public boolean deleteWeight(int weightId, String username) {

        SQLiteDatabase db = getWritableDatabase();

        int rowsDeleted = db.delete(
                "weights",
                "id = ? AND user_id = " +
                        "(SELECT id FROM users WHERE username = ?)",
                new String[]{
                        String.valueOf(weightId),
                        username
                }
        );

        return rowsDeleted > 0;
    }
    // Updates an existing weight entry for the correct user.
    public boolean updateWeight(int weightId, String username,
                                double newWeight, String newDate) {

        if (username == null || username.isEmpty()
                || newDate == null || newDate.trim().isEmpty()
                || Double.isNaN(newWeight)
                || Double.isInfinite(newWeight)
                || newWeight <= 0) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("weight", newWeight);
        values.put("date", newDate.trim());

        int rowsUpdated = db.update(
                "weights",
                values,
                "id = ? AND user_id = " +
                        "(SELECT id FROM users WHERE username = ?)",
                new String[]{
                        String.valueOf(weightId),
                        username
                });

        return rowsUpdated > 0;
    }
    // Saves or updates the user's goal weight.
    public boolean saveGoalWeight(String username, double goalWeight) {

        if (username == null || username.isEmpty()
                || !Double.isFinite(goalWeight) || goalWeight <= 0) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT id FROM users WHERE username = ?",
                new String[]{username})) {

            if (!cursor.moveToFirst()) {
                return false;
            }

            int userId = cursor.getInt(0);

            ContentValues values = new ContentValues();
            values.put("user_id", userId);
            values.put("goal_weight", goalWeight);

            return db.insertWithOnConflict(
                    "goals", null, values,
                    SQLiteDatabase.CONFLICT_REPLACE) != -1;
        }
    }

    // Retrieves the saved goal weight.
    public double getGoalWeight(String username) {

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT goals.goal_weight FROM goals " +
                        "INNER JOIN users ON goals.user_id = users.id " +
                        "WHERE users.username = ?",
                new String[]{username})) {

            if (cursor.moveToFirst()) {
                return cursor.getDouble(0);
            }
        }

        return 0;
    }

    // Retrieves the user's first recorded weight.
    public double getStartingWeight(String username) {

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT weights.weight FROM weights " +
                        "INNER JOIN users ON weights.user_id = users.id " +
                        "WHERE users.username = ? " +
                        "ORDER BY weights.id ASC LIMIT 1",
                new String[]{username})) {

            if (cursor.moveToFirst()) {
                return cursor.getDouble(0);
            }
        }

        return 0;
    }
}