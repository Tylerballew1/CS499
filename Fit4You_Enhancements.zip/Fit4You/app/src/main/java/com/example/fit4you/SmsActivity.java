package com.example.fit4you;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SmsActivity extends AppCompatActivity {

    private EditText editSmsPhoneNumber;
    private TextView textSmsStatus;
    private Button buttonEnableSms;
    private SharedPreferences preferences;
    private String userKey;

    // Handles the user's response to the SMS permission request.
    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    isGranted -> {
                        if (isGranted) {
                            saveSmsSettings(true);

                            Toast.makeText(this,
                                    "SMS notifications enabled!",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            preferences.edit()
                                    .putBoolean(userKey + "_enabled", false)
                                    .apply();

                            Toast.makeText(this,
                                    "SMS permission denied. Weight tracking still works.",
                                    Toast.LENGTH_LONG).show();
                        }

                        updateSmsStatus();
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms);

        // Identify the current user or local guest profile.
        String username = GuestHelper.resolveUsername(
                this, getIntent().getStringExtra("username"));
        userKey = (username == null || username.isEmpty())
                ? "guest" : "user_" + username;

        // Store SMS preferences locally on the device.
        preferences = getSharedPreferences(
                "Fit4YouSmsSettings", MODE_PRIVATE);

        editSmsPhoneNumber = findViewById(R.id.editSmsPhoneNumber);
        textSmsStatus = findViewById(R.id.textSmsStatus);
        buttonEnableSms = findViewById(R.id.buttonEnableSms);

        // Restore the previously entered phone number.
        editSmsPhoneNumber.setText(
                preferences.getString(userKey + "_phone", ""));

        updateSmsStatus();

        // Allow the user to enable or disable SMS notifications.
        buttonEnableSms.setOnClickListener(view -> {

            boolean enabled = preferences.getBoolean(
                    userKey + "_enabled", false);

            if (enabled) {
                saveSmsSettings(false);
                updateSmsStatus();

                Toast.makeText(this,
                        "SMS notifications disabled",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            String phoneNumber = editSmsPhoneNumber.getText()
                    .toString().trim();

            // Remove common phone number formatting.
            String digits = phoneNumber.replaceAll("[^0-9]", "");

            if ((digits.length() != 4 && digits.length() < 7)
                    || digits.length() > 15) {
                Toast.makeText(this,
                        "Please enter a valid phone number",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Ask for permission only when necessary.
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {

                saveSmsSettings(true);
                updateSmsStatus();

                Toast.makeText(this,
                        "SMS notifications enabled!",
                        Toast.LENGTH_SHORT).show();

            } else {
                // Save the number but do not enable SMS yet.
                preferences.edit()
                        .putString(userKey + "_phone", phoneNumber)
                        .apply();

                smsPermissionLauncher.launch(
                        Manifest.permission.SEND_SMS);
            }
        });

        // Keep the screen clear of system bars.
        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.smsMain), (v, insets) -> {
                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars());

                    v.setPadding(systemBars.left, systemBars.top,
                            systemBars.right, systemBars.bottom);

                    return insets;
                });

        // Find the hamburger navigation button.
        ImageButton buttonSmsMenu =
                findViewById(R.id.buttonSmsMenu);

        buttonSmsMenu.setOnClickListener(view -> {

            PopupMenu popupMenu =
                    new PopupMenu(SmsActivity.this, buttonSmsMenu);

            popupMenu.getMenuInflater().inflate(
                    R.menu.navigation_menu, popupMenu.getMenu());

            popupMenu.setOnMenuItemClickListener(item -> {

                if (item.getItemId() == R.id.menuLogin) {
                    Intent intent = new Intent(
                            SmsActivity.this, LoginActivity.class);
                    startActivity(intent);
                    return true;
                }

                if (item.getItemId() == R.id.menuWeightTracker) {
                    Intent intent = new Intent(
                            SmsActivity.this, MainActivity.class);

                    if (!userKey.equals("guest")) {
                        intent.putExtra("username",
                                userKey.substring(5));
                    }

                    startActivity(intent);
                    return true;
                }

                return item.getItemId() == R.id.menuSms;
            });

            popupMenu.show();
        });
    }

    // Save the user's notification preference.
    private void saveSmsSettings(boolean enabled) {

        String phoneNumber = editSmsPhoneNumber.getText()
                .toString().trim();

        preferences.edit()
                .putString(userKey + "_phone", phoneNumber)
                .putBoolean(userKey + "_enabled", enabled)
                .apply();
    }

    // Display whether SMS notifications are enabled.
    private void updateSmsStatus() {

        boolean enabled = preferences.getBoolean(
                userKey + "_enabled", false);

        boolean hasPermission = ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        if (enabled && hasPermission) {
            textSmsStatus.setText(R.string.sms_status_enabled);
            buttonEnableSms.setText(R.string.disable_sms_notifications);
        } else {
            textSmsStatus.setText(R.string.sms_status_disabled_label);
            buttonEnableSms.setText(R.string.enable_sms_notifications);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (preferences != null) {
            updateSmsStatus();
        }
    }
}