// CS499 Capstone Enhancement
// Tyler Ballew @SNHU
package com.example.fit4you;

// Enhancement 3.2: Separate goal calculations
// from MainActivity's UI code.
public final class WeightProgressCalculator {

    private WeightProgressCalculator() {
        // Utility class; no instances required.
    }

    // Progress is expressed as a percentage
    // between 0 and 100.
    public static int calculateProgress(
            double startingWeight,
            double currentWeight,
            double goalWeight) {

        if (!WeightEntryValidator.isValidWeight(startingWeight) ||
                !WeightEntryValidator.isValidWeight(currentWeight) ||
                !WeightEntryValidator.isValidWeight(goalWeight)) {
            return 0;
        }

        double totalChange = goalWeight - startingWeight;
        double completedChange = currentWeight - startingWeight;

        // Preserve the original progress-bar rule
        // for matching start and goal.
        if (totalChange == 0) {
            return 100;
        }

        double percentage =
                (completedChange / totalChange) * 100.0;

        percentage = Math.max(0, Math.min(100, percentage));

        return (int) Math.round(percentage);
    }

    // Support both losing and gaining weight,
    // as in the original MainActivity.
    public static boolean hasReachedGoal(
            double startingWeight,
            double currentWeight,
            double goalWeight) {

        if (!WeightEntryValidator.isValidWeight(startingWeight) ||
                !WeightEntryValidator.isValidWeight(currentWeight) ||
                !WeightEntryValidator.isValidWeight(goalWeight)) {
            return false;
        }

        if (startingWeight >= goalWeight) {
            return currentWeight <= goalWeight;
        }

        return currentWeight >= goalWeight;
    }
}