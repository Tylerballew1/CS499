package com.example.fit4you;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

public class SmsHelper {

    // Sends a goal notification only when SMS is enabled.
    public static boolean sendGoalNotification(
            Context context, String username, double weight) {

        String userKey = (username == null || username.isEmpty())
                ? "guest" : "user_" + username;

        SharedPreferences preferences = context.getSharedPreferences(
                "Fit4YouSmsSettings", Context.MODE_PRIVATE);

        boolean enabled = preferences.getBoolean(
                userKey + "_enabled", false);

        String phoneNumber = preferences.getString(
                userKey + "_phone", "");

        // Do not send if notifications are disabled.
        if (!enabled || phoneNumber.trim().isEmpty()) {
            return false;
        }

        // Never send without Android's SMS permission.
        if (ContextCompat.checkSelfPermission(
                context, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return false;
        }

        String message = "Congratulations! You reached your Fit4You "
                + "goal weight of " + weight + " lbs! Great work!";

        try {
            SmsManager smsManager = context.getSystemService(
                    SmsManager.class);

            if (smsManager == null) {
                return false;
            }

            smsManager.sendTextMessage(
                    phoneNumber, null, message, null, null);

            return true;

        } catch (Exception e) {
            return false;
        }
    }
}
