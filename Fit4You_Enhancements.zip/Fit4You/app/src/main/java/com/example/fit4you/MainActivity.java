// Tyler Ballew @SNHU.EDU
// CS360 original; CS499 Enhancement
package com.example.fit4you;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.appcompat.app.AlertDialog;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.text.InputType;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import android.app.DatePickerDialog;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Connect the weight entry fields and button.
        EditText editWeight = findViewById(R.id.editWeight);
        EditText editEntryDate = findViewById(R.id.editEntryDate);
        Button buttonAddWeight = findViewById(R.id.buttonAddWeight);

        // Enhancement 2.2
        // Open the calendar when the date field is selected.
        editEntryDate.setOnClickListener(view -> {
            showDatePicker(editEntryDate);
        });

        // Connect to the Fit4You database.
        DatabaseHelper databaseHelper = new DatabaseHelper(this);

        // Use the registered account or create a local guest profile.
        String username = GuestHelper.resolveUsername(
                this, getIntent().getStringExtra("username"));

        // Display saved weight entries when the screen opens.
        loadWeightHistory(databaseHelper, username);

        // Let the user tap the goal weight label to set or change a goal.
        TextView textGoalWeight = findViewById(R.id.textGoalWeight);
        textGoalWeight.setOnClickListener(view -> {
            if (username == null || username.isEmpty()) {
                Toast.makeText(this, "Please log in first",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            EditText input = new EditText(this);
            input.setInputType(InputType.TYPE_CLASS_NUMBER |
                    InputType.TYPE_NUMBER_FLAG_DECIMAL);
            input.setHint("Enter goal weight");
            double existingGoal = databaseHelper.getGoalWeight(username);
            if (existingGoal > 0) {
                input.setText(String.valueOf(existingGoal));
            }

            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("Set Goal Weight")
                    .setView(input)
                    .setPositiveButton("Save", null)
                    .setNegativeButton("Cancel", null)
                    .create();

            dialog.setOnShowListener(ignored ->
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                            .setOnClickListener(button -> {
                                try {
                                    double goal = Double.parseDouble(
                                            input.getText().toString().trim());
                                    if (!WeightEntryValidator.isValidWeight(goal) ||
                                            !databaseHelper.saveGoalWeight(username, goal)) {
                                        Toast.makeText(this, "Enter a valid goal weight",
                                                Toast.LENGTH_SHORT).show();
                                        return;
                                    }
                                    updateGoalProgress(databaseHelper, username);
                                    Toast.makeText(this, "Goal weight saved!",
                                            Toast.LENGTH_SHORT).show();
                                    dialog.dismiss();
                                } catch (NumberFormatException e) {
                                    Toast.makeText(this, "Enter a valid goal weight",
                                            Toast.LENGTH_SHORT).show();
                                }
                            }));
            dialog.show();
        });

        // Save the weight when the Add Weight button is pressed.
        buttonAddWeight.setOnClickListener(view -> {

            String weightText = editWeight.getText().toString().trim();
            String date = editEntryDate.getText().toString().trim();

            // Make sure both fields are completed.
            if (weightText.isEmpty() || date.isEmpty()) {
                Toast.makeText(this,
                        "Please enter a weight and date",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Enhancement 3.1: Reuse the date validation helper.
            if (!WeightEntryValidator.isValidDate(date)) {
                editEntryDate.setError("Enter a valid date (MM/DD/YYYY)");
                return;
            }

            // Only allow today's date for new weight entries.
            if (!WeightEntryValidator.isToday(date)) {
                editEntryDate.setError("Please select today's date");

                Toast.makeText(this,
                        "Weight entries must use today's date",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Verify that the user is logged in.
            if (username == null || username.isEmpty()) {
                Toast.makeText(this,
                        "Please log in first",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double weight = Double.parseDouble(weightText);

                // Only allow valid weight values.
                if (!WeightEntryValidator.isValidWeight(weight)) {
                    Toast.makeText(this,
                            "Please enter a valid weight",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                // Save the weight entry in SQLite.
                boolean success = databaseHelper.addWeight(
                        username, weight, date);

                if (success) {
                    Toast.makeText(this,
                            "Weight saved successfully!",
                            Toast.LENGTH_LONG).show();

                    // Send a notification when the new weight reaches the goal.
                    double goalWeight = databaseHelper.getGoalWeight(username);

                    if (goalWeight > 0) {
                        double startingWeight = databaseHelper.getStartingWeight(username);

                        boolean goalReached = WeightProgressCalculator.hasReachedGoal(
                                startingWeight, weight, goalWeight);

                        if (goalReached) {
                            boolean smsSent = SmsHelper.sendGoalNotification(
                                    this, username, weight);

                            if (smsSent) {
                                android.util.Log.d("Fit4You",
                                        "Goal SMS submitted for sending.");
                            }
                        }
                    }

                    editWeight.setText("");
                    editEntryDate.setText("");

                    // Refresh the grid after saving.
                    loadWeightHistory(databaseHelper, username);

                } else {
                    Toast.makeText(this,
                            "Unable to save weight",
                            Toast.LENGTH_LONG).show();
                }

            } catch (NumberFormatException e) {
                Toast.makeText(this,
                        "Please enter a valid number",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Keeps the screen clear of the system bars.
        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main), (v, insets) -> {
                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars());
                    v.setPadding(systemBars.left, systemBars.top,
                            systemBars.right, systemBars.bottom);
                    return insets;
                });

        // Finds the hamburger menu button.
        ImageButton buttonMenu = findViewById(R.id.buttonMenu);

        // Opens the menu when the hamburger button is clicked.
        buttonMenu.setOnClickListener(view -> {

            PopupMenu popupMenu =
                    new PopupMenu(MainActivity.this, buttonMenu);

            popupMenu.getMenuInflater().inflate(
                    R.menu.navigation_menu, popupMenu.getMenu());

            popupMenu.setOnMenuItemClickListener(item -> {

                // Opens the login screen.
                if (item.getItemId() == R.id.menuLogin) {
                    Intent intent = new Intent(
                            MainActivity.this, LoginActivity.class);
                    startActivity(intent);
                    return true;
                }

                // Already on the weight tracker screen.
                if (item.getItemId() == R.id.menuWeightTracker) {
                    return true;
                }

                // Opens the SMS notification screen.
                if (item.getItemId() == R.id.menuSms) {
                    Intent intent = new Intent(
                            MainActivity.this, SmsActivity.class);

                    intent.putExtra("username", username);

                    startActivity(intent);
                    return true;
                }
                return false;
            });

            popupMenu.show();
        });
    }

    // Retrieves and displays saved weight entries.
    private void loadWeightHistory(DatabaseHelper databaseHelper,
                                   String username) {

        GridLayout grid = findViewById(R.id.gridWeightHistory);

        // Remove the sample rows but keep the three headers.
        if (grid.getChildCount() > 3) {
            grid.removeViews(3, grid.getChildCount() - 3);
        }

        // Reset the displayed weight when no records are available.
        TextView currentWeight = findViewById(R.id.textCurrentWeightValue);
        currentWeight.setText(R.string.no_weight_recorded);

        // Guest access will be connected to local storage separately.
        if (username == null || username.isEmpty()) {
            updateGoalProgress(databaseHelper, username);
            return;
        }

        // Read saved weights from SQLite.
        try (Cursor cursor = databaseHelper.getUserWeights(username)) {

            // The newest inserted entry will be displayed as Current Weight.
            boolean firstEntry = true;

            while (cursor.moveToNext()) {

                String date = cursor.getString(
                        cursor.getColumnIndexOrThrow("date"));

                double weight = cursor.getDouble(
                        cursor.getColumnIndexOrThrow("weight"));

                // Get the unique ID for this weight entry.
                int weightId = cursor.getInt(
                        cursor.getColumnIndexOrThrow("id"));

                // The first record is the newest saved weight.
                if (firstEntry) {
                    currentWeight.setText(
                            getString(R.string.weight_display,
                                    String.valueOf(weight)));
                    firstEntry = false;
                }

                // Add the date to the grid.
                addHistoryCell(grid, date);

                // Add the weight to the grid and allow editing.
                TextView weightCell = addHistoryCell(
                        grid,
                        getString(R.string.weight_display,
                                String.valueOf(weight)));

                weightCell.setOnClickListener(view ->
                        showEditWeightDialog(databaseHelper, username,
                                weightId, weight, date));

                // Delete the selected weight entry.
                Button deleteButton = new Button(this);
                deleteButton.setText(R.string.delete_action);
                deleteButton.setTextSize(12);
                deleteButton.setBackgroundTintList(
                        android.content.res.ColorStateList.valueOf(
                                Color.parseColor("#DE0A0A")));

                // Enhancement 1.0: Confirm before deleting a weight entry.
                deleteButton.setOnClickListener(view -> {

                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Delete Weight Entry")
                            .setMessage("Are you sure you want to delete this weight entry? This action cannot be undone.")
                            .setNegativeButton("Cancel", null)
                            .setPositiveButton("Delete", (dialog, which) -> {

                                boolean deleted = databaseHelper.deleteWeight(
                                        weightId, username);

                                if (deleted) {
                                    Toast.makeText(this,
                                            "Weight deleted successfully!",
                                            Toast.LENGTH_SHORT).show();

                                    loadWeightHistory(databaseHelper, username);

                                } else {
                                    Toast.makeText(this,
                                            "Unable to delete weight",
                                            Toast.LENGTH_SHORT).show();
                                }
                            })
                            .show();
                });

                GridLayout.LayoutParams params =
                        new GridLayout.LayoutParams();

                params.width = GridLayout.LayoutParams.WRAP_CONTENT;
                params.height = GridLayout.LayoutParams.WRAP_CONTENT;
                params.setGravity(Gravity.CENTER);

                grid.addView(deleteButton, params);
            }
        }

        // Refresh the goal and progress display after CRUD changes.
        updateGoalProgress(databaseHelper, username);
    }

    // Creates a text cell for the weight history grid.
    private TextView addHistoryCell(GridLayout grid, String text) {

        TextView cell = new TextView(this);
        cell.setText(text);
        cell.setTextColor(Color.BLACK);
        cell.setGravity(Gravity.CENTER);
        cell.setPadding(8, 8, 8, 8);

        GridLayout.LayoutParams params =
                new GridLayout.LayoutParams();

        params.width = 0;
        params.height = GridLayout.LayoutParams.WRAP_CONTENT;
        params.columnSpec = GridLayout.spec(
                GridLayout.UNDEFINED, 1f);

        grid.addView(cell, params);
        return cell;
    }

    // Opens a dialog to edit an existing weight entry.
    private void showEditWeightDialog(DatabaseHelper databaseHelper,
                                      String username, int weightId,
                                      double weight, String date) {

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);

        EditText editWeight = new EditText(this);
        editWeight.setHint("Weight");
        editWeight.setInputType(8194);
        editWeight.setText(String.valueOf(weight));
        layout.addView(editWeight);

        // Enhancement 2.3
        // Create a date field for editing existing entries.
        EditText editDate = new EditText(this);
        editDate.setHint("Select Date");
        editDate.setText(date);

        // Open the calendar instead of the keyboard.
        editDate.setFocusable(false);
        editDate.setClickable(true);
        editDate.setCursorVisible(false);

        editDate.setOnClickListener(view -> {
            showDatePicker(editDate);
        });

        layout.addView(editDate);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit Weight Entry")
                .setView(layout)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", (d, which) -> {
                })
                .create();

        dialog.setOnShowListener(ignored -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                    .setOnClickListener(view -> {
                        try {
                            double newWeight = Double.parseDouble(
                                    editWeight.getText().toString().trim());

                            String newDate =
                                    editDate.getText().toString().trim();

                            // Make sure the edited weight is valid.
                            if (!WeightEntryValidator.isValidWeight(newWeight)) {
                                editWeight.setError(
                                        "Enter a valid weight greater than 0");
                                return;
                            }

                            // Make sure the edited date is valid.
                            if (!WeightEntryValidator.isValidDate(newDate)) {
                                editDate.setError(
                                        "Enter a valid date (MM/DD/YYYY)");
                                return;
                            }

                            // Preserve historical dates when only correcting a weight.
                            // A newly selected date must be today.
                            if (!newDate.equals(date) &&
                                    !WeightEntryValidator.isToday(newDate)) {

                                editDate.setError(
                                        "Please select today's date");

                                Toast.makeText(this,
                                        "Newly selected dates must be today",
                                        Toast.LENGTH_SHORT).show();
                                return;
                            }

                            boolean updated = databaseHelper.updateWeight(
                                    weightId, username, newWeight, newDate);

                            if (updated) {
                                Toast.makeText(this,
                                        "Weight updated!",
                                        Toast.LENGTH_SHORT).show();

                                loadWeightHistory(databaseHelper, username);
                                dialog.dismiss();
                            } else {
                                Toast.makeText(this,
                                        "Enter a valid weight and date",
                                        Toast.LENGTH_SHORT).show();
                            }

                        } catch (NumberFormatException e) {
                            Toast.makeText(this,
                                    "Please enter a valid weight",
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
        });

        dialog.show();
    }

    // Displays the saved goal and calculates progress from first to latest entry.
    private void updateGoalProgress(DatabaseHelper databaseHelper,
                                    String username) {
        TextView goalText = findViewById(R.id.textGoalWeight);
        ProgressBar progressBar = findViewById(R.id.progressWeight);
        progressBar.setMax(100);
        progressBar.setProgress(0);

        if (username == null || username.isEmpty()) {
            goalText.setText(R.string.goal_weight_prompt);
            return;
        }

        double goal = databaseHelper.getGoalWeight(username);
        if (goal <= 0) {
            goalText.setText(R.string.goal_weight_prompt);
            return;
        }

        goalText.setText(
                getString(R.string.goal_weight_display,
                        String.valueOf(goal)));

        double startingWeight =
                databaseHelper.getStartingWeight(username);

        if (startingWeight <= 0) {
            return;
        }

        double currentWeight = startingWeight;

        try (Cursor cursor = databaseHelper.getUserWeights(username)) {
            if (cursor.moveToFirst()) {
                currentWeight = cursor.getDouble(
                        cursor.getColumnIndexOrThrow("weight"));
            }
        }

        // Enhancement 3.2: Keep progress math out of the screen code.
        int progress = WeightProgressCalculator.calculateProgress(
                startingWeight, currentWeight, goal);

        progressBar.setProgress(progress);
    }

    // Opens the calendar and validates the selected date.
    private void showDatePicker(EditText dateField) {

        Calendar calendar = Calendar.getInstance();

        String existingDate =
                dateField.getText().toString().trim();

        // Show the existing date when editing a record.
        if (WeightEntryValidator.isValidDate(existingDate)) {
            LocalDate selected = LocalDate.parse(
                    existingDate,
                    DateTimeFormatter.ofPattern("MM/dd/uuuu"));

            calendar.set(
                    selected.getYear(),
                    selected.getMonthValue() - 1,
                    selected.getDayOfMonth());
        }

        DatePickerDialog datePicker = new DatePickerDialog(
                this,
                (view, year, month, day) -> {

                    LocalDate selectedDate =
                            LocalDate.of(year, month + 1, day);

                    LocalDate today = LocalDate.now();

                    // Reject dates before today.
                    if (selectedDate.isBefore(today)) {
                        dateField.setError(
                                "Past dates are not allowed");

                        Toast.makeText(this,
                                "Please select today's date",
                                Toast.LENGTH_LONG).show();
                        return;
                    }

                    // Reject future dates.
                    if (selectedDate.isAfter(today)) {
                        dateField.setError(
                                "Future dates are not allowed");

                        Toast.makeText(this,
                                "Future dates cannot be selected",
                                Toast.LENGTH_LONG).show();
                        return;
                    }

                    // Save the valid selected date.
                    String formattedDate = selectedDate.format(
                            DateTimeFormatter.ofPattern("MM/dd/uuuu"));

                    dateField.setText(formattedDate);
                    dateField.setError(null);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );

        // Disable future dates in the calendar.
        datePicker.getDatePicker().setMaxDate(
                System.currentTimeMillis());

        datePicker.show();
    }
}