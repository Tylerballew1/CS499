# CS 340 - Grazioso Salvare Dashboard

**Author:** Tyler Ballew  
**University:** Southern New Hampshire University  
**Original Course:** CS 340 - Client/Server Development  
**Enhanced Course:** CS 499 - Computer Science Capstone  
**Originally Completed:** August 2026  
**Enhanced:** November 2026  

## Project Overview

The Grazioso Salvare Dashboard was originally developed in CS 340
using Python and MongoDB. The purpose of the application is to
allow users to search through animal shelter records and identify
animals that meet specific rescue requirements. The application
uses a CRUD Python module to communicate with MongoDB and an
interactive dashboard to display information through a data table,
pie chart, and geographical map.

## CS 499 Database Enhancements

As part of my Computer Science Capstone, I enhanced this project
to improve database security, functionality, maintainability,
and reliability.

The following enhancements were completed:

- Replaced hardcoded database connection settings with
  configurable environment variables.
- Added database connection verification and timeout handling.
- Improved input validation for CRUD operations.
- Added safeguards against accidental mass updates and deletions
  caused by empty queries.
- Added protection against modifying MongoDB document identifiers.
- Improved database error handling.
- Added database indexes to support efficient queries.
- Developed a synthetic test database containing 100 animal records.
- Created automated tests to verify database functionality.
- Updated the dashboard to use the enhanced CRUD module.
- Improved dashboard error handling and data visualization.
- Replaced numerical column references with named database fields.
- Added inline comments identifying and explaining enhancements.

## Development Environment

The original project was developed using Codio. For the CS 499
enhancement, I transitioned the project to a local development
environment using Visual Studio Code.

Throughout the Computer Science program, I have worked with
several development environments and have found Visual Studio
Code to be my preferred environment due to its flexibility,
ease of use, and support for different programming languages.

### System Requirements

- Python 3.15.2
- MongoDB Community Server 9.0.4
- pip 26.2.2

### Recommended Development Environment

- Visual Studio Code
- Microsoft Python Extension
- Microsoft Jupyter Extension

### Python Dependencies

- PyMongo 4.20.2
- Dash 4.5.1
- Dash Leaflet 1.1.3
- Pandas 3.1.1
- Plotly 7.2.0
- IPython Kernel 7.4.0

## Project Files

| File | Description |
| --- | --- |
| CRUD_Python_Module.py | Enhanced MongoDB connection and CRUD operations |
| ProjectTwoDashboard.ipynb | Interactive animal rescue dashboard |
| seed_database.py | Generates the synthetic test database |
| test_crud.py | Automated database testing |
| requirements.txt | Required Python dependencies |
| README.md | Project documentation and setup instructions |

## Installation and Setup

### 1. Install Required Software

Install Python and MongoDB Community Server. Ensure MongoDB
is running locally before continuing.

Visual Studio Code is recommended for editing the Python
files and running the Jupyter Notebook.

### 2. Install Python Dependencies

Open a terminal within the project folder and run:

```powershell
python -m pip install -r requirements.txt
```

### 3. Create the Test Database

Run the following command:

```powershell
python seed_database.py
```

The script creates a synthetic database with the following
configuration:

- Host: localhost
- Port: 27017
- Database: aac_test
- Collection: animals
- Total Records: 100

The original database was hosted through Codio and was not
available during the enhancement process. A synthetic test
database was created to allow the application to be developed
and tested locally.

The test records do not represent actual animal shelter records.
The local test environment does not require authentication.
A production environment should use appropriate authentication
and database access controls.

### 4. Create Database Indexes

Run the following command:

```powershell
python -c "from CRUD_Python_Module import AnimalShelter; db = AnimalShelter(); print(list(db.create_indexes().keys())); db.close()"
```

### 5. Run Automated Tests

Run the following command:

```powershell
python test_crud.py
```

All 12 automated tests passed during development. Testing
included CRUD operations, input validation, credential
validation, database indexing, and safeguards against
unintended database modifications.

After testing was completed, all 100 synthetic animal
records remained intact.

### 6. Launch the Dashboard

1. Open ProjectTwoDashboard.ipynb in Visual Studio Code.
2. Select the Python environment as the notebook kernel.
3. Select Run All.
4. Open the following address in a web browser:

http://127.0.0.1:8050/

An internet connection is required to display the map tiles.

## Dashboard Functionality

The dashboard supports the following filtering options:

- Water Rescue
- Mountain or Wilderness Rescue
- Disaster or Individual Tracking
- Reset

Users can also sort and filter animal records, view animal
breed distributions through a pie chart, and view the
location of a selected animal through an interactive map.

## Testing Results

| Test Category | Result |
| --- | --- |
| Database Connection | Passed |
| Create Operation | Passed |
| Read Operation | Passed |
| Update Operation | Passed |
| Delete Operation | Passed |
| Input Validation | Passed |
| Security Safeguards | Passed |
| Database Indexing | Passed |
| Dashboard Functionality | Passed |
| Database Integrity | 100 Records Retained |
| Automated Tests | 12/12 Passed |

## Conclusion

This enhancement allowed me to build upon my previous work
while improving my understanding of database management,
security, and software development. By transitioning the
project to a local development environment, I was able to
improve the application's functionality and create a more
maintainable and reusable database module. This project also
reinforced the importance of testing individual components
before integrating them into a complete application.