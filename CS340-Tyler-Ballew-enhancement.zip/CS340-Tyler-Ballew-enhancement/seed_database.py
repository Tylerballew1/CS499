from pymongo import MongoClient
import random

# Establish a connection to the local MongoDB server
client = MongoClient("mongodb://localhost:27017/")

# Select the test database and collection
db = client["aac_test"]
collection = db["animals"]

# Use a consistent seed for repeatable testing
random.seed(42)

# Sample breeds based on rescue requirements
breeds = [
    "Labrador Retriever Mix",
    "Chesapeake Bay Retriever",
    "Newfoundland",
    "German Shepherd",
    "Alaskan Malamute",
    "Old English Sheepdog",
    "Siberian Husky",
    "Rottweiler",
    "Doberman Pinscher",
    "Golden Retriever",
    "Bloodhound",
    "Chihuahua Mix"
]

names = [
    "Max", "Bella", "Charlie", "Lucy",
    "Cooper", "Daisy", "Rocky", "Luna",
    "Duke", "Sadie"
]

animals = []

# Generate 100 synthetic animal records
for i in range(1, 101):
    animal_type = "Cat" if i % 10 == 0 else "Dog"

    animal = {
        "animal_id": f"TEST{i:04d}",
        "animal_type": animal_type,
        "breed": (
            random.choice(breeds)
            if animal_type == "Dog"
            else "Domestic Shorthair"
        ),
        "name": random.choice(names),
        "sex_upon_outcome": random.choice([
            "Intact Male",
            "Intact Female",
            "Neutered Male",
            "Spayed Female"
        ]),
        "age_upon_outcome_in_weeks": random.randint(10, 350),
        "outcome_type": random.choice([
            "Adoption", "Transfer"
        ]),
        "location_lat": round(
            random.uniform(30.20, 30.50), 6
        ),
        "location_long": round(
            random.uniform(-97.90, -97.60), 6
        ),
        "synthetic_data": True
    }

    animals.append(animal)

# Insert or replace synthetic test records
for animal in animals:
    collection.replace_one(
        {"animal_id": animal["animal_id"]},
        animal,
        upsert=True
    )

# Verify the database records
print("Test database created successfully.")
print(f"Database: {db.name}")
print(f"Collection: {collection.name}")
print(f"Total records: {collection.count_documents({})}")

client.close()