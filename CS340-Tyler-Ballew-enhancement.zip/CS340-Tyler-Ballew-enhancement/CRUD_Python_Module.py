# Example Python Code to Insert a Document
# Tyler Ballew @SNHU

# Enhancement: Import os to support environment-based
# database configuration instead of hardcoded settings.
import os

# Enhancement: Import ASCENDING to support database indexing
# and improve query performance.
from pymongo import MongoClient, ASCENDING
from bson.objectid import ObjectId

# Enhancement: Import PyMongoError to provide
# database-specific exception handling.
from pymongo.errors import PyMongoError

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB."""

    def __init__(self, username=None, password=None):
        """Initialize a configurable MongoDB connection."""

        # Enhancement: Use environment variables to improve
        # portability and avoid hardcoded credentials.
        uri = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
        db_name = os.getenv("MONGO_DB", "aac_test")
        collection_name = os.getenv("MONGO_COLLECTION", "animals")

        # Enhancement: Reject incomplete authentication credentials.
        if (username is None) != (password is None):
            raise ValueError(
                "Both username and password must be provided."
            )

        try:
            # Enhancement: Support optional authentication and
            # limit the time spent waiting for a database connection.
            if username is not None and password is not None:
                self.client = MongoClient(
                    uri,
                    username=username,
                    password=password,
                    serverSelectionTimeoutMS=5000
                )
            else:
                self.client = MongoClient(
                    uri,
                    serverSelectionTimeoutMS=5000
                )

            # Enhancement: Verify the database connection before
            # allowing the application to perform CRUD operations.
            self.client.admin.command("ping")

            # Select the configured database and collection.
            self.database = self.client[db_name]
            self.collection = self.database[collection_name]

        except PyMongoError as e:
            # Enhancement: Release connection resources if
            # initialization fails.
            if hasattr(self, "client"):
                self.client.close()

            raise ConnectionError(
                "Unable to connect to MongoDB."
            ) from e

    # Create method to implement the C in CRUD.
    def create(self, data):
        """Insert a document into the animals collection."""

        # Enhancement: Validate that the supplied data is
        # a non-empty dictionary before inserting a record.
        if not isinstance(data, dict) or not data:
            raise ValueError(
                "Create requires a non-empty dictionary."
            )

        try:
            # Insert the new animal document into MongoDB.
            result = self.collection.insert_one(data)

            # Return True if the document was successfully added.
            return result.inserted_id is not None

        except PyMongoError as e:
            # Enhancement: Report database failures instead
            # of silently returning an unsuccessful result.
            raise RuntimeError(
                "Unable to create animal record."
            ) from e

    # Read method to implement the R in CRUD.
    def read(self, query):
        """Search for documents that match the supplied query."""

        # Enhancement: Validate the query structure before
        # submitting it to the database.
        if not isinstance(query, dict):
            raise ValueError(
                "Read requires a dictionary query."
            )

        try:
            # Find all documents that match the query.
            result = self.collection.find(query)

            # Convert the MongoDB results into a list.
            return list(result)

        except PyMongoError as e:
            # Enhancement: Distinguish database failures
            # from legitimate searches returning no records.
            raise RuntimeError(
                "Unable to retrieve animal records."
            ) from e

    # Update method to implement the U in CRUD.
    def update(self, query, data):
        """Update documents that match the supplied query."""

        # Enhancement: Prevent empty queries from
        # unintentionally updating every database record.
        if not isinstance(query, dict) or not query:
            raise ValueError(
                "Update requires a non-empty query."
            )

        # Enhancement: Validate the supplied update data.
        if not isinstance(data, dict) or not data:
            raise ValueError(
                "Update requires a non-empty data dictionary."
            )

        # Enhancement: Prevent modification of MongoDB's
        # immutable document identifier.
        if any(
            field == "_id" or field.startswith("_id.")
            for field in data
        ):
            raise ValueError(
                "The document ID cannot be modified."
            )

        try:
            # Update documents that match the supplied query.
            result = self.collection.update_many(
                query,
                {"$set": data}
            )

            # Return the number of modified documents.
            return result.modified_count

        except PyMongoError as e:
            # Enhancement: Provide database-specific error handling.
            raise RuntimeError(
                "Unable to update animal records."
            ) from e

    # Delete method to implement the D in CRUD.
    def delete(self, query):
        """Delete documents that match the supplied query."""

        # Enhancement: Prevent empty queries from
        # unintentionally deleting every database record.
        if not isinstance(query, dict) or not query:
            raise ValueError(
                "Delete requires a non-empty query."
            )

        try:
            # Delete documents that match the supplied query.
            result = self.collection.delete_many(query)

            # Return the number of deleted documents.
            return result.deleted_count

        except PyMongoError as e:
            # Enhancement: Distinguish database failures
            # from successful operations with no matching records.
            raise RuntimeError(
                "Unable to delete animal records."
            ) from e

    # Enhancement: Add database indexes to support efficient
    # searches and improve dashboard filtering performance.
    def create_indexes(self):
        """Create indexes for commonly searched animal fields."""

        try:
            self.collection.create_index(
                [("animal_id", ASCENDING)],
                name="animal_id_index"
            )

            # Compound index supports rescue category queries
            # involving breed, sex, and age.
            self.collection.create_index(
                [
                    ("breed", ASCENDING),
                    ("sex_upon_outcome", ASCENDING),
                    ("age_upon_outcome_in_weeks", ASCENDING)
                ],
                name="rescue_filter_index"
            )

            return self.collection.index_information()

        except PyMongoError as e:
            raise RuntimeError(
                "Unable to create database indexes."
            ) from e

    # Enhancement: Allow the application to properly release
    # database connection resources when no longer needed.
    def close(self):
        """Close the MongoDB connection."""

        self.client.close()