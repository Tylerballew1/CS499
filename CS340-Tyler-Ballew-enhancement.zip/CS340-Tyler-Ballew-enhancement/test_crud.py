# Automated CRUD Testing
# Tyler Ballew @SNHU
# CS 499 - Enhancement Three: Databases

import unittest
from uuid import uuid4
from CRUD_Python_Module import AnimalShelter


# Enhancement: Introduce automated unit and integration testing
# to verify database functionality and security safeguards.
class TestAnimalShelter(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.db = AnimalShelter()

        # Enhancement: Restrict testing to the synthetic database
        # to prevent accidental changes to other databases.
        if (
            cls.db.database.name != "aac_test"
            or cls.db.collection.name != "animals"
        ):
            cls.db.close()
            raise RuntimeError("Testing requires aac_test.animals.")

    def setUp(self):
        # Enhancement: Generate a unique identifier for each test
        # to avoid modifying existing animal records.
        self.animal_id = f"CRUD_TEST_{uuid4().hex}"

        self.test_animal = {
            "animal_id": self.animal_id,
            "animal_type": "Dog",
            "name": "Test Animal",
            "breed": "German Shepherd",
            "sex_upon_outcome": "Intact Male",
            "age_upon_outcome_in_weeks": 52,
            "synthetic_data": True
        }

        self.query = {"animal_id": self.animal_id}

    # Verify that a new record can be created.
    def test_create(self):
        result = self.db.create(self.test_animal)
        self.assertTrue(result)

    # Verify that an existing record can be retrieved.
    def test_read(self):
        self.db.create(self.test_animal)

        records = self.db.read(self.query)

        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["name"], "Test Animal")

    # Verify that an existing record can be updated.
    def test_update(self):
        self.db.create(self.test_animal)

        result = self.db.update(
            self.query,
            {"name": "Updated Animal"}
        )

        self.assertEqual(result, 1)

        records = self.db.read(self.query)
        self.assertEqual(records[0]["name"], "Updated Animal")

    # Verify that a record can be deleted.
    def test_delete(self):
        self.db.create(self.test_animal)

        result = self.db.delete(self.query)

        self.assertEqual(result, 1)
        self.assertEqual(self.db.read(self.query), [])

    # Enhancement: Verify that empty documents are rejected.
    def test_empty_create(self):
        with self.assertRaises(ValueError):
            self.db.create({})

    # Enhancement: Verify that invalid read queries are rejected.
    def test_invalid_read(self):
        with self.assertRaises(ValueError):
            self.db.read("invalid query")

    # Enhancement: Verify that an empty query cannot update
    # every record in the database.
    def test_unsafe_update(self):
        with self.assertRaises(ValueError):
            self.db.update({}, {"name": "Unsafe Update"})

    # Enhancement: Verify that an empty query cannot delete
    # every record in the database.
    def test_unsafe_delete(self):
        with self.assertRaises(ValueError):
            self.db.delete({})

    # Enhancement: Verify that MongoDB document identifiers
    # cannot be modified through the CRUD module.
    def test_document_id_protection(self):
        with self.assertRaises(ValueError):
            self.db.update(self.query, {"_id": "invalid"})

    # Enhancement: Verify that a valid query with no matches
    # returns an empty list rather than an error.
    def test_no_matching_records(self):
        self.assertEqual(self.db.read(self.query), [])

    # Enhancement: Verify that incomplete authentication
    # credentials are rejected.
    def test_incomplete_credentials(self):
        with self.assertRaises(ValueError):
            AnimalShelter(username="test")

    # Enhancement: Verify that the database indexes exist.
    def test_database_indexes(self):
        indexes = self.db.collection.index_information()

        self.assertIn("animal_id_index", indexes)
        self.assertIn("rescue_filter_index", indexes)

    def tearDown(self):
        # Enhancement: Remove only the temporary record
        # associated with the current test.
        self.db.delete(self.query)

    @classmethod
    def tearDownClass(cls):
        # Enhancement: Release database connection resources
        # after all tests have completed.
        cls.db.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)