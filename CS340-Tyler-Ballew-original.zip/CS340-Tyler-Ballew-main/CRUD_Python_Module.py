# Example Python Code to Insert a Document
# Tyler Ballew @SNHU

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = username
        PASS = password
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        """Insert a document into the animals collection."""

        # Check that data was provided before trying to add it
        if data is not None:
            try:
                # Insert the new animal document into MongoDB
                result = self.collection.insert_one(data)

                # Return True if the document was successfully added
                return result.inserted_id is not None

            except Exception as e:
                print("Create error:", e)
                return False
        else:
            return False 

    # Create method to implement the R in CRUD.
    def read(self, query):
        """Search for documents that are tied specifically to search query."""

        # Check that a query was provided before searching the database
        if query is not None:
            try:
                # Find all documents that match the query
                result = self.collection.find(query)

                # Convert the MongoDB results into a list
                return list(result)

            except Exception as e:
                print("Error:", e)
                return []
        else:
            return []

    # Update method to implement the U in CRUD
    def update(self, query, data):
        """Update documents that match the supplied query."""

        # Make sure both the search query and updated data were provided
        if query is not None and data is not None:
            try:
                # Update all documents that match the query
                result = self.collection.update_many(
                    query,
                    {"$set": data}
                )

                # Return the number of documents that were updated
                return result.modified_count

            except Exception as e:
                print("Update error:", e)
                return 0
        else:
            return 0

    # Delete method to implement the D in CRUD
    def delete(self, query):
        """Delete documents that match the supplied query."""

        # Check that a query was provided before deleting records
        if query is not None:
            try:
                # Delete all documents that match the query
                result = self.collection.delete_many(query)

                # Return the number of documents that were deleted
                return result.deleted_count

            except Exception as e:
                print("Delete error:", e)
                return 0
        else:
            return 0 # Standard